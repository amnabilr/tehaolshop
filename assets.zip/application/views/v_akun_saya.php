<div class="card card-solid">
    <div class="card-body pb-0">
    </div>
</div>